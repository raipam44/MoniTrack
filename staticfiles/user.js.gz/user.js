document.addEventListener('DOMContentLoaded', function() {


let logoutTimer;

function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, 1.8e+6); // 10 minutes in milliseconds
}

function logoutUser() {
    // Perform logout actions
    window.location.href = '/logout';
}

// Attach event listeners to user activity events (e.g., mousemove, keypress)
document.addEventListener('mousemove', handleUserActivity);
document.addEventListener('keypress', handleUserActivity);



// Start the timer when the page loads
resetLogoutTimer();

// Function to handle user activity
function handleUserActivity() {
    resetLogoutTimer();
   
}




});